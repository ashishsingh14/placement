#include <iostream>
#include <limits.h>
#include <list>
#include <map>
#include <queue>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <string>
#include <stack>
#include <algorithm>
using namespace std;
#define size 50
int m,n;
int row[] = {1,-1,0};
int col[] = {0,0,1};
int dp[size][size];

long long int answer = -1;


void function2()
{
    int n,m;
    cin>>n>>m;
    list<int>*adj = new list<int>[n];
    int a,b;
    for(int i =0;i<n-1;i++)
    {
        cin>>a>>b;
        adj[a-1].push_back(b-1);
        adj[b-1].push_back(a-1);
    }


    int x,y;
    int distance[n];
    bool visited[n];
    bool festive[n];
    memset(festive,false,sizeof(festive));
    while(m--)
    {
        cin>>x>>y;
        queue<int>q;
        y = y-1;
        memset(distance,0,sizeof(distance));
        memset(visited,false,sizeof(visited));
        festive[0] = true;
        if(x==1)
        {
            festive[y] = true;
            continue;
        }
        else if(x==2 && festive[y]==true)
        {
            cout<<"0"<<endl;
            continue;
        }
        else if(x==2 && festive[y]==false)
        {
            q.push(y);
            visited[y] = true;;
            distance[y]  = 0;
            int ans = -1;
            while(!q.empty())
            {
                int top = q.front();
                q.pop();
                if(festive[top])
                {
                    ans = distance[top];
                    break;
                }
                list<int>::iterator i;
                for(i = adj[top].begin();i!=adj[top].end();i++)
                {
                    if(!visited[*i])
                    {
                        visited[*i] = true;
                        distance[*i] = distance[top] + 1;
                        q.push(*i);
                    }
                }
            }
            cout<<ans<<endl;
        }

    }


}



int main()
{
    function2();
    return 0;
}


